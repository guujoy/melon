- how to assemble the tank:
https://youtu.be/WVh493hh9QQ

- how to make the shell/ how to load:
https://youtu.be/g9L38OJ4CqI
https://youtu.be/zdcTj1hofAI